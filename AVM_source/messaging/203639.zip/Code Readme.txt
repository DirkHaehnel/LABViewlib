This is a MSVC++ 6.0 project.  Either open the .dsp file if you have MSVC, 
or simply inspect the .cpp file with a text viewer.