// Windows Messages for LabVIEW.cpp : Defines the entry point for the DLL application.
//
/**********************************************************************/
/* This DLL is designed to work with LabVIEW.                         */
/* It installs a Windows Hook to inspect all messages passed to the   */
/* LabVIEW window and generate LabVIEW occurrences bassed on those    */
/* messages.                                                          */
/*                                                                    */
/* This DLL takes advantage of the ability for LabVIEW occurrences to */
/* be set from outside of LabVIEW.  It uses the API calls LoadLibrary */
/* and GetProcAddress to get the address of the labview.exe exported  */
/* function Occur which has the following prototype:                  */
/*                                                                    */
/*    MgErr __cdecl Occur(LVRefNum o);                                */
/*                                                                    */
/* Using this, an occurrence in LabVIEW that is waiting for a windows */
/* message may be set.                                                */
/*                                                                    */
/* Standards:                                                         */
/* Functions that fail return negative values.  Specific failure      */
/* specified by specific negative number, as defined by each function.*/
/* Successful functions return positive values.  Certain status info  */
/* may be specified by the specific return value.                     */
/**********************************************************************/

#include "stdafx.h"
#include <windows.h>
#include "d:\program files\national instruments\labview\cintools\extcode.h"

#include "EventInfoList.h"

//Define various types needed
//LabVIEW Array
typedef struct {
	int32 dimSize;
	uInt32 arg1[1];
	} TD1;
typedef TD1 **TD1Hdl;

//DLL Global Variables.  (Global to each process.)
HHOOK hGetHook;  //The GetMessage hook handle.
HHOOK hCallHook; //The CallWndProc hook
FARPROC Occur; //A function pointer to the Occur function inside LabVIEW.exe
EventInfoList EIL; //The list of message queues and associated info.

//Function prototypes.  All export functions declared exter "C"
//to prevent decoration.
extern "C" {
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 );

	int __declspec(dllexport) ConfigMessaging(LVRefNum *occurrence, LVRefNum *ptargethWnd, TD1Hdl msgs);
	int __declspec(dllexport) GetNextMsg(LVRefNum *occurrence, MSG* msg, LVBoolean* postorsend);
	int __declspec(dllexport) ClearMsgQueue(LVRefNum *occurrence);
	int __declspec(dllexport) MsgQueueSize(LVRefNum *occurrence);
	int __declspec(dllexport) ClearMessaging(LVRefNum *occurrence);
	int __declspec(dllexport) NotAQueue(LVRefNum *occurrence);
#ifdef _DEBUG
	int __declspec(dllexport) ForceMsg(LVRefNum *occurrence, MSG* msg);
#endif

}

LRESULT CALLBACK GMProcessMessage(
  int code,       // hook code
  WPARAM wParam,  // removal flag
  LPARAM lParam   // address of structure with message
);
LRESULT CALLBACK CWPProcessMessage(
  int code,       // hook code
  WPARAM wParam,  // removal flag
  LPARAM lParam   // address of structure with message
);

/*********************************************************************/
/*End of headers, start of code.                                     */
/*********************************************************************/

//DLL entry point.
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	HINSTANCE LVInstance;  //The handle to the LabVIEW code.

#ifdef _DEBUG
	DWORD lasterr=0;
	char location[100];
#endif
	
	//DllMain does initialization and cleanup of DLL.
	switch(ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		//Initialize globals.
		hGetHook=NULL;
		hCallHook=NULL;
		LVInstance=NULL;

		//Get module handle of LabVIEW in order to find
		//address of Occur function in labview.exe
		LVInstance = GetModuleHandle(NULL);
		if(LVInstance != NULL)
		{
			Occur = GetProcAddress(LVInstance, "Occur");
		}
		else
		{
#ifdef _DEBUG
			lasterr = GetLastError();
			strcpy(location, "DllMain : GetModuleHandle(NULL)");
#endif
			Occur = NULL;
		}
		
		//GetProcAddess may fail if this DLL is called from a LabVIEW built
		//application.  Get Occur from lvrt.dll.
		if(Occur == NULL)
		{
			LVInstance = GetModuleHandle("lvrt.dll");
			if(LVInstance != NULL)
			{
				Occur = GetProcAddress(LVInstance, "Occur");
#ifdef _DEBUG
				if(Occur == NULL)
				{
					lasterr = GetLastError();
					strcpy(location, "DllMain : GetProcAddress #2");
				}
			}
			else
			{
				lasterr = GetLastError();
				strcpy(location, "DllMain : GetModuleHandle(\"lvrt.dll\")");
#endif
			}
		}

#ifdef _DEBUG
		if(lasterr)
		{
			char errmsg[100];
			sprintf(errmsg, "Windows Error %i occured at %s.", lasterr, location);
			MessageBox(NULL, errmsg, "Windows Message Queue Debug Message", MB_OK);
			return FALSE;
		}
#endif

		if(Occur)
		{	
			return TRUE;
		}
		else
		{
			MessageBox(NULL, "Error initializing Windows Message Queue\n(This is nothing you can fix.)", "Windows Message Queue", MB_OK);
			return FALSE;
		}
		break;

	case DLL_PROCESS_DETACH:
		//Check if hook is still installed and unhook if it is.
		if(hGetHook != NULL)
		{
			UnhookWindowsHookEx(hGetHook);
		}
		if(hCallHook != NULL)
		{
			UnhookWindowsHookEx(hCallHook);
		}
		return TRUE;
		break;

	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	default:
		return TRUE;
	}

	return TRUE;
}

//ConfigMessaging creates a new windows message queue.
//Requires an pointer to an occurrence refnum, a pointer
//to a windows handle refnum, and an array of messages to which to
//sensitize the new queue.
//Return values:
//-2: Failed to create new EVENTINFO struct.  Not enought memeory.
//-1: Failed to install hook
//1: OK
//2: Queue already existed, no action taken.
int __declspec(dllexport) ConfigMessaging(LVRefNum *occurrence, LVRefNum *ptargethWnd, TD1Hdl msgs)
{
	HWND LVhWnd = (HWND)(*ptargethWnd);
	EVENTINFO *ei;
	LVRefNum o = *occurrence;

	if(EIL.size()==0)
	{
		//DLL not previously in use.
		//Install a new GetMsgHook to process the messages.
		//Only one hook of each type is needed for any number of queues.
		DWORD targetThread = GetWindowThreadProcessId(LVhWnd, NULL);

		hGetHook = SetWindowsHookEx(WH_GETMESSAGE, &GMProcessMessage, NULL, targetThread);
		hCallHook = SetWindowsHookEx(WH_CALLWNDPROC, &CWPProcessMessage, NULL, targetThread);
	}

	//Check to see if the queue already exists.  If so, return with 2
	ei = EIL.GetElementByO(o);
	if(ei != NULL)
		return 2;
	else
	{
		//Queue does not exist.  Create it.
		ei = new EVENTINFO; //Create new EVENTINFO structure
		if(ei == NULL)
			return -2;
		ei->O = o;          //Set O value
		ei->LVhWnd = LVhWnd;//Set target window handle.
		
		//Create a new array into which to copy the messages
		//array for local storage.
		ei->MsgArrayLen = (*msgs)->dimSize;
		ei->MsgArray = new unsigned long [ei->MsgArrayLen];
		
		//Copy the messages array
		for(int i=0; i<ei->MsgArrayLen; i++)
		{
			ei->MsgArray[i] = (*msgs)->arg1[i];
		}

		//Add the new EVENTINFO struct to the list of all queues.
		EIL.push_front(ei);
	}
	
	//If the hook installation failed, return -1
	//else everything is fine, return 1.
	if(hGetHook != NULL && hCallHook != NULL)
		return 1;
	else
		return -1;
}

/*GMProcessMessage is the callback for the hook procedure installed
by SetWindowsHookEx in ConfigMessaging.  It is called whenever
GetMessage is called by the target application (LabVIEW) to remove
a message from the (application) message queue before the 
message is passed to LabVIEW.  It allows us to inspect the message
to determine if it is one of the ones in which we are interested, and
take the appropriate action

Return Values:
Always returns the value of CallNextHookEx
*/
LRESULT CALLBACK GMProcessMessage(
  int code,       // hook code
  WPARAM wParam,  // removal flag
  LPARAM lParam   // address of structure with message
)
{
	if(code != HC_ACTION || wParam != PM_REMOVE)
		return CallNextHookEx(hGetHook, code, wParam, lParam);

	//else code == HC_ACTION, and the message is being removed. 
	//process...

	static EVENTINFO *ei;
	static MSG *msg;
	
	msg	= (MSG*)lParam;

	//Must check all queues to see if any are sensitized to this
	//message.

	EIL.BeginEnumQueuesByMessage(msg->message);

	while((ei = EIL.GetNextQueueByMessage()) != NULL)
	{
		if(ei->LVhWnd == msg->hwnd)
		{
			//It is a message to which this queue is sensitized 
			//and that this window received.
			//Add the message to the queue.
			ei->MQ.push(*msg);
			ei->PSQ.push(false);
			//Call the LabVIEW Occur function for this queue's
			//occurrence (ei->O).
			((int (__cdecl *)(LVRefNum))(*Occur))(ei->O);
		}
	}

	return CallNextHookEx(hGetHook, code, wParam, lParam);
}

//Callback for CallWndProc hook.
LRESULT CALLBACK CWPProcessMessage(
  int code,       // hook code
  WPARAM wParam,  // removal flag
  LPARAM lParam   // address of structure with message
)
{
	if(code != HC_ACTION || wParam != PM_REMOVE)
		return CallNextHookEx(hCallHook, code, wParam, lParam);

	//else code == HC_ACTION, and the message is being removed. 
	//process...

	static EVENTINFO *ei;
	static CWPSTRUCT* cwps;
	static MSG msg;

	cwps = (CWPSTRUCT*)lParam;

	//Must check all queues to see if any are sensitized to this
	//message.

	EIL.BeginEnumQueuesByMessage(cwps->message);

	while((ei = EIL.GetNextQueueByMessage()) != NULL)
	{
		if(ei->LVhWnd == cwps->hwnd)
		{
			msg.hwnd = cwps->hwnd;
			msg.message = cwps->message;
			msg.wParam = cwps->wParam;
			msg.lParam = cwps->lParam;
			msg.time = 0;
			msg.pt.x = 0;
			msg.pt.y = 0;

			//It is a message to which this queue is sensitized 
			//and that this window received.
			//Add the message to the queue.
			ei->MQ.push(msg);
			ei->PSQ.push(true);
			//Call the LabVIEW Occur function for this queue's
			//occurrence (ei->O).
			((int (__cdecl *)(LVRefNum))(*Occur))(ei->O);
		}
	}

	return CallNextHookEx(hCallHook, code, wParam, lParam);
}

//Removes the oldest message from the queue and returns it via msg.
//and returns whether it was posted (false) or sent (true) through postorsend
//Return Values:
//1: OK
//-1: invalid queue
//-2: no elements in queue
int __declspec(dllexport) GetNextMsg(LVRefNum *occurrence, MSG* msg, LVBoolean* postorsend)
{
	EVENTINFO *ei;

	ei = EIL.GetElementByO(*occurrence);
	
	//Check if this is a valid queue.
	if(ei != NULL)
	{
		//It is valid, check if empty
		if(!ei->MQ.empty())
		{
			//It's not empty, return the oldest msg and remove it
			//from the queue.
			*msg = ei->MQ.front(); //copy of msg
			ei->MQ.pop();
			*postorsend = ei->PSQ.front();
			ei->PSQ.pop();
			return 1;
		}
		else //It is empty
			return -2;
	}
	else //It is not valid
		return -1;
}

//Remove all pending messages in the specified queue:
//Return Values:
//The number of elements deleted
//OR
//-1: invalid queue.
int __declspec(dllexport) ClearMsgQueue(LVRefNum *occurrence)
{
	EVENTINFO *ei;

	ei = EIL.GetElementByO(*occurrence);

	//Check if queue is valid.
	if(ei != NULL)
	{
		//it is valid
		int i=0;

		//Remove each element from the queue until list is empty
		while(!ei->MQ.empty())
		{
			ei->MQ.pop();
			ei->PSQ.pop();
			i++;
		}

		return i;
	}
	else
		return -1;
}

//Return the number of messages waiting in the specified queue
//or -1 if the queue is invalid
int __declspec(dllexport) MsgQueueSize(LVRefNum *occurrence)
{
	EVENTINFO *ei;

	ei = EIL.GetElementByO(*occurrence);
	//Check if queue is valid
	if(ei != NULL)
	{
		return ei->MQ.size();
	}
	else
		return -1;
}

#ifdef _DEBUG
//Utility for testing purposed to allow for manual insertion of
//messages into the queue.
int __declspec(dllexport) ForceMsg(LVRefNum *occurrence, MSG* msg)
{
	EVENTINFO *ei;
	ei = EIL.GetElementByO(*occurrence);

	if(ei != NULL)
	{
		ei->MQ.push(*msg);
		ei->PSQ.push(false);
		((int (__cdecl *)(LVRefNum))(*Occur))(ei->O);
		return 1;
	}
	else
		return -1;
}
#endif

//ClearMessaging removes the specified windows message queue from the
//queue list, and frees any resources it was holding.
//If ClearMessaging removes the last queue from the list, it also
//frees LabVIEW.exe and unhooks the hook.
//Return Values:
//1: OK
//2: Removed last queue.
//-1: invalid queue.
//-2: Was last queue but failed to uninstall a hook.
int __declspec(dllexport) ClearMessaging(LVRefNum *occurrence)
{
	int val;

	val = EIL.ClearMessaging(occurrence);

	if(val == 2)
	{
		//We removed the last queue.  Unhook.
		val = UnhookWindowsHookEx(hGetHook);
		if(val)
		{
			hGetHook = NULL;
			val = UnhookWindowsHookEx(hCallHook);
			if(val)
			{
				hCallHook = NULL;
				val=2;
			}
			else
				val=-2;
		}
		else
			val = -2;
	}

	return val;
}


//NotAQueue checks to see if occurrence points to a valid windows
//message queue.
//Return Values:
//1: occurrence is not a valid queue
//0: occurrence is a valid queue
int __declspec(dllexport) NotAQueue(LVRefNum *occurrence)
{
	EVENTINFO *ei;

	ei = EIL.GetElementByO(*occurrence);

	if(ei == NULL)
		return 1;
	else
		return 0;
}