/*This defines the EventInfoList class used in the Windows Message
Queue DLL.  It provides multithreaded protection for the underlying
standard template library list.
*/
#ifndef EVENTINFOLIST_H
#define EVENTINFOLIST_H

#include <windows.h>
#include "d:\program files\national instruments\labview\cintools\extcode.h"
#include <deque>
#include <queue>
#include <list>

using namespace std;

//Define the message queue type.
typedef deque<MSG> MSGDEQUE;
typedef queue<MSG> MSGQUEUE;
typedef deque<bool> POSTSENDDEQUE;
typedef queue<bool> POSTSENDQUEUE;


//Define a structure to contain all information about a message being
//processed.
typedef struct {
	LVRefNum O;
	HWND LVhWnd;
	unsigned long MsgArrayLen;
	unsigned long *MsgArray;
	MSGQUEUE MQ;
	POSTSENDQUEUE PSQ;
} EVENTINFO;

//Define a list or EVENTINFO types
typedef list<EVENTINFO*> EVENTINFOLIST;

class EventInfoList : private EVENTINFOLIST
{
public:
	EventInfoList();
	virtual ~EventInfoList();

	inline int size() { return this->EVENTINFOLIST::size(); }; 
	void pop_front();
	void pop_back();
	void push_front(EVENTINFO*);
	void push_back(EVENTINFO*);

	EVENTINFO* GetElementByO(LVRefNum o);
	int ClearMessaging(LVRefNum* o);

	int BeginEnumQueuesByMessage(UINT message);
	EVENTINFO* GetNextQueueByMessage();

private:
	UINT enummsg;
	int iterator;
	HANDLE hMutex;
};

#endif //EVENTINFOLIST_H