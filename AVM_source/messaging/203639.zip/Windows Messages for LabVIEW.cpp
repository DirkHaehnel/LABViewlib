// Windows Messages for LabVIEW.cpp : Defines the entry point for the DLL application.
//
/**********************************************************************/
/* This DLL is designed to work with LabVIEW.                         */
/* It installs a Windows Hook to inspect all messages passed to the   */
/* LabVIEW window and generate LabVIEW occurrences bassed on those    */
/* messages.                                                          */
/*                                                                    */
/* This DLL takes advantage of the ability for LabVIEW occurrences to */
/* be set from outside of LabVIEW.  It uses the API calls LoadLibrary */
/* and GetProcAddress to get the address of the labview.exe exported  */
/* function Occur which has the following prototype:                  */
/*                                                                    */
/*    MgErr __cdecl Occur(LVRefNum o);                                */
/*                                                                    */
/* Using this, an occurrence in LabVIEW that is waiting for a windows */
/* message may be set.                                                */
/*                                                                    */
/* Standards:                                                         */
/* Functions that fail return negative values.  Specific failure      */
/* specified by specific negative number, as defined by each function.*/
/* Successful functions return positive values.  Certain status info  */
/* may be specified by the specific return value.                     */
/**********************************************************************/

#include "stdafx.h"
#include <windows.h>
#include "d:\program files\national instruments\labview\cintools\extcode.h"
#include <deque>
#include <queue>
#include <list>

using namespace std;

//Define various types needed
//LabVIEW Array
typedef struct {
	int32 dimSize;
	uInt32 arg1[1];
	} TD1;
typedef TD1 **TD1Hdl;

//Define the message queue type.
typedef deque<MSG> MSGDEQUE;
typedef queue<MSG> MSGQUEUE;

//Define a structure to contain all information about a message being
//processed.
typedef struct {
	LVRefNum O;
	HWND LVhWnd;
	unsigned long MsgArrayLen;
	unsigned long *MsgArray;
	MSGQUEUE MQ;
} EVENTINFO;

//Define a list or EVENTINFO types
typedef list<EVENTINFO*> EVENTINFOLIST;

//DLL Global Variables.
HHOOK hHook;  //The hook handle.
FARPROC Occur; //A function pointer to the Occur function inside LabVIEW.exe
EVENTINFOLIST EIL; //The list of message queues and associated info.

//Function prototypes.  All export functions declared exter "C"
//to prevent decoration.
extern "C" {
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 );

	int __declspec(dllexport) ConfigMessaging(LVRefNum *occurrence, LVRefNum *ptargethWnd, TD1Hdl msgs);
	int __declspec(dllexport) GetNextMsg(LVRefNum *occurrence, MSG* msg);
	int __declspec(dllexport) ClearMsgQueue(LVRefNum *occurrence);
	int __declspec(dllexport) MsgQueueSize(LVRefNum *occurrence);
	int __declspec(dllexport) ClearMessaging(LVRefNum *occurrence);
	int __declspec(dllexport) ForceMsg(LVRefNum *occurrence, MSG* msg);
	int __declspec(dllexport) NotAQueue(LVRefNum *occurrence);

}

LRESULT CALLBACK ProcessMessage(
  int code,       // hook code
  WPARAM wParam,  // removal flag
  LPARAM lParam   // address of structure with message
);
EVENTINFO* GetElementByO(LVRefNum o);

/*********************************************************************/
/*End of headers, start of code.                                     */
/*********************************************************************/

//DLL entry point.
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	HINSTANCE LVInstance;  //The handle to the LabVIEW code.

#ifdef _DEBUG
	DWORD lasterr=0;
	char location[100];
#endif
	
	//DllMain does initialization and cleanup of DLL.
	switch(ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		//Initialize globals.
		hHook=NULL;
		LVInstance=NULL;
		EIL.clear();

		//Get module handle of LabVIEW in order to find
		//address of Occur function in labview.exe
		LVInstance = GetModuleHandle(NULL);
		if(LVInstance != NULL)
		{
			Occur = GetProcAddress(LVInstance, "Occur");
		}
		else
		{
#ifdef _DEBUG
			lasterr = GetLastError();
			strcpy(location, "DllMain : GetModuleHandle(NULL)");
#endif
			Occur = NULL;
		}
		
		//GetProcAddess may fail if this DLL is called from a LabVIEW built
		//application.  Get Occur from lvrt.dll.
		if(Occur == NULL)
		{
			LVInstance = GetModuleHandle("lvrt.dll");
			if(LVInstance != NULL)
			{
				Occur = GetProcAddress(LVInstance, "Occur");
#ifdef _DEBUG
				if(Occur == NULL)
				{
					lasterr = GetLastError();
					strcpy(location, "DllMain : GetProcAddress #2");
				}
			}
			else
			{
				lasterr = GetLastError();
				strcpy(location, "DllMain : GetModuleHandle(\"lvrt.dll\")");
#endif
			}
		}

#ifdef _DEBUG
		if(lasterr)
		{
			char errmsg[100];
			sprintf(errmsg, "Windows Error %i occured at %s.", lasterr, location);
			MessageBox(NULL, errmsg, "Windows Message Queue Debug Message", MB_OK);
			return FALSE;
		}
#endif

		if(Occur)
		{	
			return TRUE;
		}
		else
		{
			MessageBox(NULL, "Error initializing Windows Message Queue\n(This is nothing you can fix.)", "Windows Message Queue", MB_OK);
			return FALSE;
		}
		break;

	case DLL_PROCESS_DETACH:
		EIL.clear();
		//Check if hook is still installed and unhook if it is.
		if(hHook != NULL)
		{
			UnhookWindowsHookEx(hHook);
		}
		return TRUE;
		break;

	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	default:
		return TRUE;
	}

	return TRUE;
}

//ConfigMessaging creates a new windows message queue.
//Requires an pointer to an occurrence refnum, a pointer
//to a windows handle refnum, and an array of messages to which to
//sensitize the new queue.
//Return values:
//-1: Failed to install hook
//1: OK
//2: Queue already existed, no action taken.
int __declspec(dllexport) ConfigMessaging(LVRefNum *occurrence, LVRefNum *ptargethWnd, TD1Hdl msgs)
{
	HWND LVhWnd = (HWND)(*ptargethWnd);
	EVENTINFO *ei;
	LVRefNum o = *occurrence;

	if(EIL.size()==0)
	{
		//DLL not previously in use.
		//Install a new GetMsgHook to process the messages.
		//HINSTANCE LVInstance = LoadLibrary("labview.exe");
		//Only one hook is needed for any number of queues.
		DWORD targetThread = GetWindowThreadProcessId(LVhWnd, NULL);

		hHook = SetWindowsHookEx(WH_GETMESSAGE, &ProcessMessage, NULL, targetThread);
	}

	//Check to see if the queue already exists.  If so, return with 2
	ei = GetElementByO(o);
	if(ei != NULL)
		return 2;
	else
	{
		//Queue does not exist.  Create it.
		ei = new EVENTINFO; //Create new EVENTINFO structure
		ei->O = o;          //Set O value
		ei->LVhWnd = LVhWnd;//Set target window handle.
		
		//Create a new array into which to copy the messages
		//array for local storage.
		ei->MsgArrayLen = (*msgs)->dimSize;
		ei->MsgArray = new unsigned long [ei->MsgArrayLen];
		
		//Copy the messages array
		for(int i=0; i<ei->MsgArrayLen; i++)
		{
			ei->MsgArray[i] = (*msgs)->arg1[i];
		}

		//Add the new EVENTINFO struct to the list of all queues.
		EIL.push_front(ei);
	}
	
	//If the hook installation failed, return -1
	//else everything is fine, return 1.
	if(hHook != NULL)
		return 1;
	else
		return -1;
}

/*ProcessMessage is the callback for the hook procedure installed
by SetWindowsHookEx in ConfigMessaging.  It is called whenever
GetMessage is called by the target application (LabVIEW) to remove
a message from the (application) message queue before the 
message is passed to LabVIEW.  It allows us to inspect the message
to determine if it is one of the ones in which we are interested, and
take the appropriate action

Return Values:
Always returns the value of CallNextHookEx
*/
LRESULT CALLBACK ProcessMessage(
  int code,       // hook code
  WPARAM wParam,  // removal flag
  LPARAM lParam   // address of structure with message
)
{
	int i, j;

	if(code != HC_ACTION || wParam != PM_REMOVE)
		return CallNextHookEx(hHook, code, wParam, lParam);

	//else code == HC_ACTION, and the message is being removed. 
	//process...

	MSG *msg = (MSG*)lParam;
	EVENTINFO *ei;

	//Must check all queues to see if any are sensitized to this
	//message.
	//Note: there's definately a better way to do this, such 
	//as keeping the message array's sorted, for one.  But,
	//that hasn't happened yet.
	for(j=0; j<EIL.size(); j++)
	{
		ei=EIL.front();

		//Check all messages in the array to see if this
		//queue is sensitized to this message.
		for(i=0; i<ei->MsgArrayLen; i++)
		{
			//Check vs. list of messages.  Also check to make
			//sure that this message was posted to the
			//window in which we are interested.
			if(msg->message == ei->MsgArray[i] && msg->hwnd == ei->LVhWnd)
			{
				//It is a message to which this queue is sensitized 
				//and that this window received.
				//Add the message to the queue.
				ei->MQ.push(*msg);
				//Call the LabVIEW Occur function for this queue's
				//occurrence (ei->O).
				((int (__cdecl *)(LVRefNum))(*Occur))(ei->O);
				break;
			}
		}
		//Move the last element to the back of the list.
		//(i.e. rotate the list)
		EIL.pop_front();
		EIL.push_back(ei);
	}
	return CallNextHookEx(hHook, code, wParam, lParam);
}

//Removes the oldest message from the queue and returns it via msg.
//Return Values:
//1: OK
//-1: invalid queue
//-2: no elements in queue
int __declspec(dllexport) GetNextMsg(LVRefNum *occurrence, MSG* msg)
{
	EVENTINFO *ei;

	ei = GetElementByO(*occurrence);
	
	//Check if this is a valid queue.
	if(ei != NULL)
	{
		//It is valid, check if empty
		if(!ei->MQ.empty())
		{
			//It's not empty, return the oldest msg and remove it
			//from the queue.
			*msg = ei->MQ.front();
			ei->MQ.pop();
			return 1;
		}
		else //It is empty
			return -2;
	}
	else //It is not valid
		return -1;
}

//Remove all pending messages in the specified queue:
//Return Values:
//The number of elements deleted
//OR
//-1: invalid queue.
int __declspec(dllexport) ClearMsgQueue(LVRefNum *occurrence)
{
	EVENTINFO *ei;

	ei = GetElementByO(*occurrence);

	//Check if queue is valid.
	if(ei != NULL)
	{
		//it is valid
		int i=0;

		//Remove each element from the queue until ist is empty
		while(!ei->MQ.empty())
		{
			ei->MQ.pop();
			i++;
		}

		return i;
	}
	else
		return -1;
}

//Return the number of messages waiting in the specified queue
//or -1 if the queue is invalid
int __declspec(dllexport) MsgQueueSize(LVRefNum *occurrence)
{
	EVENTINFO *ei;

	ei = GetElementByO(*occurrence);
	//Check if queue is valid
	if(ei != NULL)
	{
		return ei->MQ.size();
	}
	else
		return -1;
}


//ClearMessaging removes the specified windows message queue from the
//queue list, and frees any resources it was holding.
//If ClearMessaging removes the last queue from the list, it also
//frees LabVIEW.exe and unhooks the hook.
//Return Values:
//1: OK
//2: Removed last queue.
//-1: invalid queue.
int __declspec(dllexport) ClearMessaging(LVRefNum *occurrence)
{
	int val=1;
	EVENTINFO *ei;

	ei = GetElementByO(*occurrence);

	//Make sure it's a valid queue before removing it.
	if(ei != NULL)
	{
		delete ei->MsgArray;
		delete ei;
		//the queue should be left in the from the GetElementByO
		//call, so, just pop the front item.
		EIL.pop_front();
		//Check to see if this was the last item in the list.
		if(EIL.size() == 0)
		{
			//It was.  Unhook and free labview.exe
			val = UnhookWindowsHookEx(hHook);
			if(val)
			{
				hHook = NULL;
				val = 2;
			}
		}
		
		return val;
	}
	else
		return -1;
}

//Utility for testing purposed to allow for manual insertion of
//messages into the queue.
int __declspec(dllexport) ForceMsg(LVRefNum *occurrence, MSG* msg)
{
	EVENTINFO *ei;
	ei = GetElementByO(*occurrence);

	if(ei != NULL)
	{
		ei->MQ.push(*msg);
		((int (__cdecl *)(LVRefNum))(*Occur))(ei->O);
		return 1;
	}
	else
		return -1;
}

//NotAQueue checks to see if occurrence points to a valid windows
//message queue.
//Return Values:
//1: occurrence is not a valid queue
//0: occurrence is a valid queue
int __declspec(dllexport) NotAQueue(LVRefNum *occurrence)
{
	EVENTINFO *ei;

	ei = GetElementByO(*occurrence);

	if(ei == NULL)
		return 1;
	else
		return 0;
}

//Helper to return EVENTINFO struct by occurrence value
//Cycles through all EVENTINFO elements in the list looking 
//for one whose O member matches o.
//Return s a pointer to the EVENTINFO struct with matching O member
//or NULL if none is found.
//Leaves the matching EVENTINFO struct at the head of the list.
EVENTINFO* GetElementByO(LVRefNum o)
{
	EVENTINFOLIST::iterator iter;
	EVENTINFO* ei;

	//For each element in the list.
	for(int i=0; i<EIL.size(); i++)
	{
		//Check to see if ei->O matche o
		ei = EIL.front();
		if((UINT)ei->O == (UINT)o)
			return ei; //it does, return it.
		else
		{
			//It doesn't.  Rotate the list.
			EIL.pop_front();
			EIL.push_back(ei);
		}
	}
	//If we haven't returned yet, then the desired element does not
	//exist.  Return NULL.
	return NULL;
}
