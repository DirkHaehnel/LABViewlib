#include "stdafx.h"
#include "EventInfoList.h"

EventInfoList::EventInfoList()
{
	this->clear();
	hMutex = CreateMutex(NULL, FALSE, NULL);
}

EventInfoList::~EventInfoList()
{
	EVENTINFO *ei;

	for(int i=0; i < size(); i++)
	{
		ei = this->front();
		delete ei->MsgArray;
		delete ei;
		this->pop_front();
	}
	this->clear();
	CloseHandle(hMutex);
}

void EventInfoList::pop_front()
{
	WaitForSingleObject(hMutex, INFINITE);
	this->EVENTINFOLIST::pop_front();
	ReleaseMutex(hMutex);
}

void EventInfoList::pop_back()
{
	WaitForSingleObject(hMutex, INFINITE);
	this->EVENTINFOLIST::pop_back();
	ReleaseMutex(hMutex);
}

void EventInfoList::push_front(EVENTINFO* ei)
{
	WaitForSingleObject(hMutex, INFINITE);
	this->EVENTINFOLIST::push_front(ei);
	ReleaseMutex(hMutex);
}

void EventInfoList::push_back(EVENTINFO* ei)
{
	WaitForSingleObject(hMutex, INFINITE);
	this->EVENTINFOLIST::push_back(ei);
	ReleaseMutex(hMutex);
}

//Helper to return EVENTINFO struct by occurrence value
//Cycles through all EVENTINFO elements in the list looking 
//for one whose O member matches o.
//Return s a pointer to the EVENTINFO struct with matching O member
//or NULL if none is found.
//Leaves the matching EVENTINFO struct at the head of the list.
EVENTINFO* EventInfoList::GetElementByO(LVRefNum o)
{
	EVENTINFO* ei;

	WaitForSingleObject(hMutex, INFINITE);

	//For each element in the list.
	for(int i=0; i<this->size(); i++)
	{
		//Check to see if ei->O matche o
		ei = this->front();
		if((UINT)ei->O == (UINT)o)
		{
			ReleaseMutex(hMutex);
			return ei; //it does, return it.
		}
		else
		{
			//It doesn't.  Rotate the list.
			this->pop_front();
			this->push_back(ei);
		}
	}

	ReleaseMutex(hMutex);

	//If we haven't returned yet, then the desired element does not
	//exist.  Return NULL.
	return NULL;
}


//ClearMessaging removes the specified windows message queue from the
//queue list, and frees any resources it was holding.
//If ClearMessaging removes the last queue from the list, it also
//frees LabVIEW.exe and unhooks the hook.
//Return Values:
//1: OK
//2: Removed last queue.
//-1: invalid queue.
int EventInfoList::ClearMessaging(LVRefNum *occurrence)
{
	int val=1;
	EVENTINFO *ei;

	WaitForSingleObject(hMutex, INFINITE);

	ei = this->GetElementByO(*occurrence);

	//Make sure it's a valid queue before removing it.
	if(ei != NULL)
	{
		delete ei->MsgArray;
		delete ei;
		//The queue should be left in the front from the GetElementByO
		//call, so, just pop the front item.
		this->pop_front();
		//Check to see if this was the last item in the list.
		if(this->size() == 0)
		{
			val = 2;
		}
	}
	else
		val = -1;

	ReleaseMutex(hMutex);

	return val;
}

/*Call to begin iterating through list of queues looking for
queues that are waiting for the specified message.  Call
GetNextQueueByMessage repeatedly until it returns NULL immediately
after calling this function.  Returns the size of the list.  It
is critical that the list not be modified by the calling thread
during the message enumeration*/
int EventInfoList::BeginEnumQueuesByMessage(UINT message)
{
	WaitForSingleObject(hMutex, INFINITE);
	enummsg = message;
	iterator = 0;
	//Mutex Released by GetNextQueueByMessage.
	return this->size();
}

/*After a call to BeginGetQueueByMessage, this function must
be called until it returns NULL.  This should not be called unless
a call to BeginGetQueueMessage has preceded it.*/
EVENTINFO* EventInfoList::GetNextQueueByMessage()
{
	EVENTINFO* ei;
	int i=0;
	bool hasmsg = false;

	//Mutex Acquired By BeginEnumQueuesByMessage 

	//Check to make sure that we haven't already completed.
	if(iterator < this->size())
	{
		//Search through queues until one is found that
		//has the message or we have looked at all queues.
		do
		{
			ei = this->front();
			hasmsg = false;
			//Check every message in the queue's sensitization
			//list to see if we are interested in this one.
			for(i=0; i < ei->MsgArrayLen && !hasmsg; i++)
			{
				if(ei->MsgArray[i] == enummsg)
				{
					hasmsg = true;
				}
				else
				{
					hasmsg = false;
				}
			}
			this->pop_front();
			this->push_back(ei);
			iterator++;
		}while(iterator < this->size() && hasmsg == false);
		
		//Check to see if we finished going through the
		//list items and return NULL and release mutex
		//if so.
		if(iterator >= this->size() && hasmsg == false)
		{
			ei = NULL;
			ReleaseMutex(hMutex);
		}
	}
	else
	{
		//We have already reached the end of the list.
		//Return NULL and release the mutex.
		ei = NULL;
		ReleaseMutex(hMutex);
	}

	return ei;
}